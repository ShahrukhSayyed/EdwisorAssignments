/*JSON DATA START HERE*/

var products = [{

		"Main Category":"Electronics",
		"Category":"Mobiles",
		"Brand Name":"Apple",
		"Name": "Apple iPhone 8 Plus",
		"Highlights": ["5.5 inch Retina HD Display",
			"12MP + 12MP Dual Rear Camera",
			"7MP Front Camera",
			"lithium-ion Battery",
			"A11 Bionic Chip with 64-bit Architecture",
			"Neural Engine",
			"Embedded M11 Motion Coprocessor Processor"
		],
		"Color": ["Silver", "Gold", "Space grey"],
		"Storage": [64, 256],

		"Warranty": "Brand Warranty of 1 Year",
		"Price": 80000,
		"Discount": "21%",
		"Price After Discount": 72000,
		"PaymentOptions": ["EMI", "Cash on Delivery", "Net banking & Credit/ Debit/ ATM card"],
		"Photos": ["image1", "image2", "image3", "image4", "image5"],

		"Seller": {
			"name": "SuperComNet",
			"rating": "4.1"
		},
		"Product Description": "An all-new glass design, an updated camera, and a powerful chip, there’s so much to love about the iPhone 8 Plus. This iPhone brings you an augmented reality experience that’s more immersive than before. What’s more? You can charge your iPhone wirelessly! ",

		"Features": ["Wireless Charging", "Water and Dust Resistant (IP67)", "All-new Retina HD Display", "True Tone Technology"],
		"Specifications": [{
			"General": {
				"In The Box": "Handset, EarPods with Lightning Connector, Lightning to 3.5 mm Headphone Jack Adapter, Lightning to USB Cable, USB Power Adapter, Documentation",
				"Model Number": "MQ8G2HN/A",
				"Model Name": "iPhone 8 Plus",
				"Color": "Space Grey",
				"Browse Type": "Smartphones",
				"SIM Type": "Single Sim",
				"Touchscreen": "Yes",
				"Sound Enhancements": "Built-in Stereo Speaker, Built-in Microphone"
			},
			"Display Features": {
				"Display Size": "5.5 inch",
				"Resolution": "1920 x 1080 Pixels",
				"Resolution Type": "Retina HD Display",
				"Display Type": "Widescreen LCD Multi-touch Display with IPS Technology",
				"Other Display Features": "1300:1 Contrast Ratio (Typical), True Tone Display, Wide Color Display (P3), 3D Touch, 625 cd/m2 Max Brightness (Typical), Dual-domain Pixels for Wide Viewing Angles, Fingerprint-resistant Oleophobic Coating, Support for Display of Multiple Languages and Characters Simultaneously, Display Zoom, Reachability"
			},
			"Os Processor Features": {
				"Operating System": "iOS iOS 11",
				"Processor Type": "A11 Bionic Chip with 64-bit Architecture, Neural Engine, Embedded M11 Motion Coprocessor",
				"Operating Frequency": "GSM/EDGE (850, 900, 1800, 1900 MHz), UMTS / HSPA+ / DC-HSDPA - (850, 900, 1700 / 2100, 1900, 2100 MHz), 4G TD-LTE (Bands 34, 38, 39, 40, 41)"
			},


			"Memory Storage Features": {
				"Internal Storage": "256 GB"
			},
			"Camera Features": {
				"Primary Camera Available": "Yes",
				"Primary Camera": "12MP + 12MP",
				"Primary Camera Features": "Wide-angle and Telephoto Cameras, Wide-angle: f/1.8 Aperture, Telephoto: f/2.8 Aperture, Portrait Mode, Portrait Lighting (Beta)",
				"Optical Zoom": "Yes",
				"Secondary Camera Available": "Yes",
				"Secondary Camera": "7MP"
			},
			"Connectivity Features": {
				"Network Type": "4G, 2G, 3G",
				"Supported Networks": "4G LTE, UMTS, GSM, WCDMA",
				"Internet Connectivity": "4G, 3G, Wi-Fi, EDGE"
			},
			"Other Details": {
				"Smartphone": "Yes",
				"Sensors": "Touch ID Fingerprint Sensor Built into the Home Button, Barometer, Three-axis Gyro, Accelerometer, Proximity Sensor, Ambient Light Sensor",
				"Supported Languages": "Multi-language Support"
			},

			"Warranty": {
				"Warranty Summary": "Brand Warranty of 1 Year"
			}


		}],



		"Rating And Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "It was an awesome Product",
			"ReviewBy": "Certified Buyer",
			"Date": "12 Jan 2018",
			"likes": 120,
			"dislikes": 10
		},
		{
			"rating": 4,
			"ReviewsHeading": "Good Product",
			"ReviewsDescription": "It was an good Product",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]

	},

	{

		"Main Category":"Electronics",
		"Category":"Mobiles",
		"Brand Name":"Oppo",	
		"Name": "Oppo F1 Plus",
		"Highlights": ["5.5 inch Retina HD Display",
			"12MP + 12MP Dual Rear Camera",
			"20MP Front Camera",
			"lithium-ion Battery",
			"Neural Engine"
		],
		"Color": ["Black", "Gold", "grey"],
		"Storage": [32, 64],
		"Warranty": "Brand Warranty of 1 Year",
		"Price": 23000,
		"Discount": "10%",
		"Price After Discount": 22000,
		"Payment Options": ["EMI", "Cash on Delivery", "Net banking & Credit/ Debit/ ATM card"],
		"Photos": ["image1", "image2", "image3", "image4", "image5"],
		"Seller": {
			"Name": "SuperComNet",
			"rating": "4.1"
		},
		"product Description": "An all-new glass design, an updated camera, and a powerful chip, there’s so much to love about the iPhone 8 Plus. This iPhone brings you an augmented reality experience that’s more immersive than before. What’s more? You can charge your iPhone wirelessly! ",

		"Features": ["Water and Dust Resistant (IP67)", "All-new Retina HD Display", "True Tone Technology"],
		"Specifications": [{
			"General": {
				"In The Box": "Handset, Lightning to 3.5 mm Headphone Jack Adapter, USB Power Adapter, Documentation",
				"Model Number": "MQ8G2HN1/B",
				"Model Name": "Oppo F1 Plus",
				"Color": "Black",
				"Browse Type": "Smartphones",
				"SIM Type": "Dual Sim",
				"Touchscreen": "Yes",
				"Sound Enhancements": "Built-in Stereo Speaker, Built-in Microphone"
			},
			"Display Features": {
				"Display Size": "5.5 inch",
				"Resolution": "1920 x 1080 Pixels",
				"Resolution Type": "Retina HD Display"
			},
			"Os & Processor Features": {
				"Operating System": "Android Naugut",
				"Processor Type": "A11 Bionic Chip with 64-bit Architecture, Neural Engine, Embedded M11 Motion Coprocessor"
			},
			"Memory & Storage Features": {
				"Internal Storage": "128 GB"
			},
			"Camera Features": {
				"Primary Camera Available": "Yes",
				"Primary Camera": "12MP + 12MP",
				"Primary Camera Features": "Wide-angle and Telephoto Cameras, Wide-angle: f/1.8 Aperture, Telephoto: f/2.8 Aperture, Portrait Mode, Portrait Lighting (Beta)",
				"Optical Zoom": "Yes",
				"Secondary Camera Available": "Yes",
				"Secondary Camera": "20MP"
			},

			"Connectivity Features": {
				"Network Type": "4G, 2G, 3G",
				"Supported Networks": "4G LTE, UMTS, GSM, WCDMA",
				"Internet Connectivity": "4G, 3G, Wi-Fi, EDGE"
			},
			"Other Details": {
				"Smartphone": "Yes",
				"Sensors": "Touch ID Fingerprint Sensor Built into the Home Button, Ambient Light Sensor",
				"Supported Languages": "Multi-language Support"
			},
			"Warranty": {
				"Warranty Summary": "Brand Warranty of 1 Year"
			}
		}],



		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "It was an awesome Product",
			"ReviewBy": "Certified Buyer",
			"Date": "12 Jan 2018",
			"likes": 120,
			"dislikes": 10
		},

		{
			"rating": 4,
			"ReviewsHeading": "Good Product",
			"ReviewsDescription": "It was an good Product",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]

	},

	{

		"Main Category":"Electronics",

		"Category":"Mobile Accessories",
		"Sub Category":"Headphones and Headsets",
		"Brand Name":"Skullcandy",
		"Name": "Skullcandy S5LHZ-J576",
		"Color": ["Carcole black", "Navy Blue", "White Gery"],
		"Description": "Skullcandy S5LHZ-J576 Anti Headphone  (Charcoal Black, On the Ear)",
		"Special Price": 699,
		"Price": 1999,
		"Discount": "65%",
		"Photos": ["image1", "image2", "image3", "image4", "image5"],
		"Highlights": [
			"Design: Over the Head",
			"Type: Stereo",
			"Compatible With: Mobile",
			"Headphone Jack: 3.5",
			"In-the-ear Headphone",
			"1.2 m Symmetric Cable",
			"Innovative Finger-Contoured"
		],
		"Services": [
			"1 Year Skullcandy India Warranty",
			"10 Days Replacement Policy",
			"Cash on Delivery available"
		],
		"Seller": {
			"Name": "SuperComNet",
			"Rating": 4.5
		},
		"Specifications": [{
			"General": {
				"Model Name": "S5LHZ-J576 Anti",
				"Color": "Charcoal Black",
				"Headphone Type": "On the Ear",
				"Inline Remote": "No",
				"Sales Package": "Headphone"
			},
			"Warranty": {
				"Warranty Summary": "1 Year Skullcandy India Warranty",
				"Covered in Warranty": "Manufacturing Defect",
				"Not Covered in Warranty": "Physically Damaged"
			}
		}],

		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "It was an awesome Product",
			"ReviewBy": "Certified Buyer",
			"Date": "12 Jan 2018",
			"likes": 120,
			"dislikes": 10
		},
		{
			"rating": 4,
			"ReviewsHeading": "Good Product",
			"ReviewsDescription": "It was an good Product",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]

	},
	{
		"Main Category":"Electronics",

		"Category":"Laptops",
		"Brand Name":"Apple",
		"Name": "Apple MacBook Air",
		"Highlights": ["Intel Core i5 Processor (5th Gen)", "8 GB DDR3 RAM", "64 bit Mac OS Operating System", "128 GB SSD", "13.3 inch Display"],
		"Warranty": "1 Year Onsite Warranty",
		"Price": 56000,
		"Discount": "12%",
		"Price After Discount": 52000,
		"Photos": ["image1", "image2", "image3", "image4", "image5"],
		"Payment Options": ["EMI", "Cash on Delivery", "Net banking & Credit/ Debit/ ATM card"],
	
		"Seller": {
			"Name": "RetaillNet",
			"rating": "4.9"
		},
		"Product Description": "Apple MacBook Air Core i5 5th Gen - (8 GB/128 GB SSD/Mac OS Sierra) MQD32HN/A A1466  (13.3 inch, SIlver, 1.35 kg)",
		"Specifications": [{
			"General": {
				"Sales Package": "Laptop, Battery, Power Adaptor, User Guide, Warranty Documents",
				"Model Number": "MQD32HN/A A1466",
				"Part Number": "MQD32HN/A",
				"Series": "MacBook Air",
				"Color": "SIlver",
				"Type": "Thin and Light Laptop",
				"Suitable For": "Processing & Multitasking, Travel & Business",
				"Battery Backup": "Upto 12 hours",
				"Power Supply": "45 W MagSafe 2 Power Adapter"
			},
			"Processor And Memory Features": {
				"Processor Brand": "Intel",
				"Processor Name": "Core i5",
				"Processor Generation": "5th Gen",
				"SSD": "Yes",
				"SSD Capacity": "128 GB",
				"RAM": "8 GB",
				"RAM Type": "DDR3",
				"Clock Speed": "1.8 GHz with Turbo Boost Upto 2.9 GHz",
				"RAM Frequency": "1600 MHz",
				"Cache": "3 MB",
				"Graphic Processor": "Intel Integrated HD 6000"
			},
			"Operating System": {
				"OS Architecture": "64 bit",
				"Operating System": "Mac OS Sierra",
				"System Architecture": "64 bit"
			},
			"Additional Features": {
				"Disk Drive": "Not Available",
				"Web Camera": "720p FaceTime HD Camera",
				"Keyboard": "Full-size Backlit Keyboard",
				"Pointer Device": "Multi-Touch Trackpad",
				"Included Software": ["Siri", "Safari", "App Store", "iMovie", "GarageBand", "Keynote", "FaceTime", "iBooks", "iTunes"],
				"Additional Features": "Lithium Polymer Battery"
			},

			"Warranty": {
				"Warranty Summary": "1 Year Onsite Warranty",
				"Warranty Service Type": "Onsite",
				"Covered in Warranty": "Manufacturing Defects",
				"Not Covered in Warranty": "Warranty does not cover any physical damage. Accesories is also not covered under warranty:- adapter, battery. Software Damage is Also not covered",
				"Domestic Warranty": "1 Year",
				"International Warranty": "1 Year"
			}
		}],


		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "Great product. Got it at 41600 at BBD sale. Thanks Flipkart",
			"ReviewBy": "Shahrukh Sayyed",
			"Date": "6 Jan 2018",
			"likes": 10,
			"dislikes": 1
		},
		{
			"rating": 1,
			"ReviewsHeading": "Hated it!",
			"ReviewsDescription": "Product is excellent no doubt!But i paid 66k for it and now there are giving it away only at 44k Hit ",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]
	},
	{
		"Main Category":"Electronics",

		"Category":"Camera",
		"Camera Type":"DSLR",
		"Name": "Nikon D3400 DSLR Camera",
		"Description": "Nikon D3400 DSLR Camera Body with Single Lens: AF-P DX NIKKOR 18-55 mm f/3.5-5.6G VR Kit (16 GB SD Card + Camera Bag)  (Black)",
		"Price": 36950,
		"Discount": "31%",
		"Special Price": 28990,
		"Lens Attachment": ["18-55 mm", "18-55 mm + 70-300 mm"],
		"Photos": ["image1", "image2", "image3", "image4", "image5"],
		"Highlights": ["Effective Pixels: 24.2 MP", "Sensor Type: CMOS", "HD, Full HD"],
		"Seller": {
			"Name": "RetailNet",
			"Rating": 4.2
		},
	
		"Services": ["2 Years Nikon India Warranty", "10 Days Replacement Policy", "Cash on Delivery available"],
		"Specifications": [{
			"General": {
				"Brand": "Nikon",
				"Model Number": "D3400",
				"Model Name": "D3400",
				"SLR Variant": "Body with Single Lens: AF-P DX NIKKOR 18-55 mm f/3.5-5.6G VR Kit (16 GB SD Card + Camera Bag)",
				"Type": "DSLR",
				"Color": "Black",
				"Effective Pixels": "24.2 MP",
				"Tripod Socket": "Yes",
				"Wifi": "No",
				"Face Detection": "Yes",
				"Temperature": "0°C - 40°C",
				"Accessory Shoe": "ISO 518 Hot-shoe with Sync, Data Contacts and Safety Lock"
			},
			"Warranty": {
				"Warranty Summary": "2 Years Nikon India Warranty",
				"Not Covered in Warranty": "Warranty does not cover any external accessories (such as battery, cable, carrying bag), damage caused to the product due to improper installation by customer"
			}
		}],

		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "Great product. Got it at 41600 at BBD sale. Thanks Flipkart",
			"ReviewBy": "Shahrukh Sayyed",
			"Date": "6 Jan 2018",
			"likes": 10,
			"dislikes": 1
		},
		{
			"rating": 1,
			"ReviewsHeading": "Hated it!",
			"ReviewsDescription": "Product is excellent no doubt!But i paid 66k for it and now there are giving it away only at 44k Hit ",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]
	},
	{
		"Main Category":"Electronics",

		"Category":"Camera",
		"Camera Type":"Point and Shoot",
		"Name": "Sony DSC-W830/BC",
		"Description": "Sony DSC-W830/BC Point & Shoot Camera  (Black)",
		"Price": 8099,
		"Discount": "N/A",
		"Special Price": 8099,
		"Photos": ["image1", "image2", "image3", "image4", "image5"],
		"Highlights": ["Effective Pixels: 20.1 MP", "Optical Zoom: 8 ", "Digital Zoom: 32x", "Sensor Type: CMOS", "LCD Size: 2.7 inch", "Max Shutter Speed: 1/30", "Auto Focus"],
		"Seller": {
			"Name": "RetailNet",
			"Rating": 4.2
		},
		"Services": ["2 Years Nikon India Warranty", "10 Days Replacement Policy", "Cash on Delivery available"],
		"Specifications": [{
			"General": {
				"Sales Package": "AC AdaptorAC-UB10C/UB10D, Rechargeable Battery Pack NP-BN, Instruction Manual, Multi USB cable, Wrist Strap, AC Power Cord",
				"Model Name": "DSC-W830/BC",
				"Series": "Cyber-shot",
				"Type": "Point & Shoot",
				"Effective Pixel": "20.1 MP",
				"Screen Resolution Type": "20.1 megapixels",
				"Optical Zoom": "8",
				"Maximum Shutter Speed": "1/30 sec"
			},
			"Warranty": {
			"Warranty Summary": "2 Years Nikon India Warranty",
				"Not Covered in Warranty": "Warranty does not cover any external accessories (such as battery, cable, carrying bag), damage caused to the product due to improper installation by customer"
			}
		}],

		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "Great product. Got it at 41600 at BBD sale. Thanks Flipkart",
			"ReviewBy": "Shahrukh Sayyed",
			"Date": "6 Jan 2018",
			"likes": 10,
			"dislikes": 1
		},
		{
			"rating": 1,
			"ReviewsHeading": "Hated it!",
			"ReviewsDescription": "Product is excellent no doubt!But i paid 66k for it and now there are giving it away only at 44k Hit ",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]

	},
	{
		"Main Category":"Appliances",
		"Category":"Televisions",	
		"Name": "Sanyo",
		"Description": "Sanyo 107.95cm (43 inch) Full HD LED Smart TV  (XT-43S8100FS)",
		"Price": 46990,
		"Discount": "27%",
		"Special Price": 33990,
		"Display Size": [43, 49],
		"Photos": ["image1", "image2", "image3", "image4", "image5"],
		"Highlights": [
			"16 W Speaker Output",
			"1920 x 1080 Full HD - Watch Blu-ray movies at their highest level of detail",
			"60 Hz : Standard refresh rate for blur-free picture quality",
			"3 x HDMI : For set top box, consoles and Blu-ray players",
			"2 x USB : Easily connect your digital camera, camcorder or USB device"
		],
		"Seller": {
			"Name": "OmniTechRetail",
			"Rating": 4.1
		},
		"Services": [
			"No cost EMI starting from ₹2,834/month",
			"Cash on Delivery",
			"Net banking & Credit/ Debit/ ATM card",
			"10 Days Replacement Policy"
		],
		"Specifications": [{
			"General": {
				"In The Box": "1 TV Unit,Pedestal,Remote,2 Batteries,User Manual,Wall Mount",
				"Model Name": "XT-43S8100FS",
				"Display Size": "107.95 cm (43)",
				"Screen Type": "LED",
				"HD Technology & Resolution": "Full HD, 1920 x 1080",
				"3D": "No",
				"Smart TV": "Yes",
				"Curve TV": "No",
				"Touchscreen": "No",
				"Motion Sensor": "No",
				"HDMI": 3,
				"USB": 2,
				"Built In Wi-Fi": "Yes",
				"Launch Year": 2017
			},
			"Warranty": {
				"Warranty Summary": "1 Year Sanyo India Warranty",
				"Covered in Warranty": "Defect Arising Out of Faulty or Defective Material or Workmanship. Parts and Labour Costs are Covered",
				"Not Covered in Warranty": "Physical Damages after Usage, Scratches on Panel"
			},
			"Installation and Demo": {
				"Installation and Demo Details": "We'll facilitate the installation and demo through authorized service engineer at your convenience. The installation will be done within 48 hours of delivery of the TV. The service engineer will install your new TV, either on wall mount or on table top. Installation and demo are provided free of cost. The engineer will also help you understand your new TV's features. The process generally covers: Wall-mounted or table-top installation, as requested. Physical check of all ports, including power and USB ports. Accessories also checked. Demonstration of features and settings, Quick run-through on how to operate the TV"
			}
		}],

		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "Great product. Got it at 41600 at BBD sale. Thanks Flipkart",
			"ReviewBy": "Shahrukh Sayyed",
			"Date": "6 Jan 2018",
			"likes": 10,
			"dislikes": 1
		},
		{
			"rating": 1,
			"ReviewsHeading": "Hated it!",
			"ReviewsDescription": "Product is excellent no doubt!But i paid 66k for it and now there are giving it away only at 44k Hit ",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]
	},

	{
		"Main Category":"Men Wear",
		"Category":"Top wear",
		"Wear Type":"Shirts",
		"Name": "John Players ",
		"Description": "John Players Men's Solid Formal Dark Blue Shirt",
		"Price": 999,
		"Discount": "40%",
		"Special Price": 449,
		"Size": [41, 42, 43, 44],
		"Photos": ["image1", "image2", "image3", "image4", "image5"],

		"Highlights": [
			"Fabric: Cotton",
			"Regular Fit, Full Sleeve",
			"Collar Type: Spread Collar",
			"Pattern: Solid",
			"Set of 1"
		],

		"Seller": {
			"Name": "RetailTech",
			"Rating": 4.1
		},
		"Services": [
			"30 Days Refund/Exchange",
			"Cash on Delivery available"
		],
		"Specifications": {
			"Model Details": "This model has a Height of 6 feet 0 inches and is wearing a of Size 40",
			"Pack of": 1,
			"Style Code": "JFMWSHCOR7059003Navy",
			"Closure": "Button",
			"Fit": "Regular",
			"Fabric": "Cotton",
			"Sleeve": "Full Sleeve",
			"Pattern": "Solid",
			"Reversible": "No",
			"Collar": "Spread Collar",
			"Fabric Care": "Machine Wash as per Tag, Wash with Like Colors, Do not Bleach, Line Dry, Dry in Shade, Iron Steam or Dry as per Tag, Do not Iron on Print/Embroidery/Embellishment",
			"Hem": "Straight Hem",
			"Placket": "Button Down Placket",
			"Pockets": "1 Patch Pocket on Chest"
		},

		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "Great product. Got it at 41600 at BBD sale. Thanks Flipkart",
			"ReviewBy": "Shahrukh Sayyed",
			"Date": "6 Jan 2018",
			"likes": 10,
			"dislikes": 1
		},
		{
			"rating": 1,
			"ReviewsHeading": "Hated it!",
			"ReviewsDescription": "Product is excellent no doubt!But i paid 66k for it and now there are giving it away only at 44k Hit ",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]
	},
	{

		"Main Category":"Men Wear",
		
		"Category":"Bottom wear",
		"Wear Type": "Trousers",
		"Name": "John Players ",
		"Description": "John Players Regular Fit Men's Grey Trousers",
		"Price": 1599,
		"Discount": "50%",
		"Special Price": 759,
		"Size": [32, 34, 36, 38],
		"Photos": ["image1", "image2", "image3", "image4", "image5"],
		"Highlights": [
			"Fabric: Cotton",
			"Pattern: Solid",
			"Set of 1"
		],

		"Seller": {
			"Name": "RetailTech",
			"Rating": 4.1
		},
		"Services": [
			"30 Days Refund/Exchange",
			"Cash on Delivery available"
		],
		"Specifications": {
			"Model Details": "This model has a height of 6 feet 0 inches, Waist 32 inches, Hip 38 inches and is wearing a of Size",
			"Pack of": 1,
			"Type": "Tailored Trousers",
			"Suitable For": "Western Wear",
			"Pattern": "Solid",
			"Fit": "Regular Fit",
			"Occasion": "Formal",
			"Fabric": "Viscose",
			"Pleats": "Flat Front",
			"Fabric Care": "Machine wash as per tag",
			"Other Details": "Logo Detail on Front Right Pocket"
		},
		"Rating and Reviews": [{
			"rating": 5,
			"ReviewsHeading": "Awesome Product",
			"ReviewsDescription": "Great product. Got it at 41600 at BBD sale. Thanks Flipkart",
			"ReviewBy": "Shahrukh Sayyed",
			"Date": "6 Jan 2018",
			"likes": 10,
			"dislikes": 1
		},

		{
			"rating": 1,
			"ReviewsHeading": "Hated it!",
			"ReviewsDescription": "Product is excellent no doubt!But i paid 66k for it and now there are giving it away only at 44k Hit ",
			"ReviewBy": "Certified Buyer",
			"Date": "11 Jan 2018",
			"likes": 150,
			"dislikes": 30
		}]

	}];

/*JSON DATA ENDS HERE*/