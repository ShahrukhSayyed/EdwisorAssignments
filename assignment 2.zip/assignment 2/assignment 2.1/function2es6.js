let bubble_sort = (array) => {

	let swapp;
	let n = array.length-1;
	let tempArray = array;
	
	do{
		swapp  = false;
		
		for(let i=0;i<n ;i++){
			if(tempArray[i] < tempArray[i+1]){
				let temp = tempArray[i];
				tempArray[i] = tempArray[i+1];
				tempArray[i+1] = temp;
				swapp=true
			}
		}
		n--;

	}while(swapp);
	return tempArray;
}

const array = [4,2,3,5,6,7];
console.log(bubble_sort(array));


//let,arrow  
