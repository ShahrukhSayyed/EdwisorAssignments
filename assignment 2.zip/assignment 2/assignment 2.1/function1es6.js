const allUsersData = [
	{
		email:"tedtalks@gmail.com",
		password:"password@123",
		name:"Ted Talks",
		id:"001"
	},
	{
		email:"saiamazon@gmail.com",
		password:"logon@1098",
		name:"Sail Mehrotra ",
		id:"002"
	},
	{
		email:"coolking@gmail.com",
		password:"chat@#2",
		name:"Cool King",
		id:"003"
}];



let checkLogin = (email,password,allUsers) => {
	let isUserFound=false
	let passwordCorrect =false
	let foundUserName = ""

	for(currentUser of allUsers){

		console.log(currentUser)
		if(currentUser.email == email){
			if(currentUser.password == password){
				isUserFound=true
				passwordCorrect=true
				foundUserName = currentUser.name
				break

			}else{
				isUserFound=true
				passwordCorrect=false	
			}
		}
		else{
			isUserFound=false
		}
	}//end for-in loop

	if(isUserFound == true && passwordCorrect == true){
		alert(`${foundUserName} is loged in successfully`)
	}else if(isUserFound == true && passwordCorrect==false){
		alert(`The given password is not associated with this email : ${email}`)
	}else{
		alert(`No account is found with this email : ${email}`)
	}
	
} //end of checkLogin function



checkLogin("tedtalks@gmail.com","password@123",allUsersData)